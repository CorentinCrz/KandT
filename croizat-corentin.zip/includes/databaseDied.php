<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>LOL la base est morte</title>
</head>
<body>
    <span style="font-size: 340px">HAHAHAHAH</span>
</body>
</html>
