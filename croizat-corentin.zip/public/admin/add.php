<?php
require_once "../../includes/functionsAdmin.php";
crudHead("Ajouter une page");
displayAdd();