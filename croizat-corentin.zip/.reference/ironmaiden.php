<?php include "includes/header.php"?>
    <div class="container theme-showcase" role="main">
        <div class="jumbotron">
            <h1>Iron Maiden!</h1>
            <p>C'est vieux.</p>
            <span class="label label-success">SIX SIX SIX!!! the number of the beast!!</span>
        </div>
        <img class="img-thumbnail" alt="Iron Maiden" src="img/ironmaiden.jpg" data-holder-rendered="true">
    </div>
<?php include "includes/footer.php"?>