<?php include "includes/header.php"?>
    <div class="container theme-showcase" role="main">
        <div class="jumbotron">
            <h1>Les Chatons!</h1>
            <p>C'est mignon.</p>
            <span class="label label-success">Kawaiiii!</span>
        </div>
        <img class="img-thumbnail" alt="Teletubbies" src="img/three_kittens.jpg" data-holder-rendered="true">
    </div>
<?php include "includes/footer.php"?>