<?php
include_once "includes/includez.php";
include_once "includes/includez.php";
//require_once "includes/existepas.php";
xon();
