<?php
for ($i=1;$i<=5;$i++) {
    include "includes/includez2lavengeance.php";
}