<?php
/**
 * Created by PhpStorm.
 * @author Yann Le Scouarnec <bunkermaster@gmail.com>
 * Date: 07/03/2018
 * Time: 14:51
 */
$content = [
    'teletubbies' => [
        "title" => "Teletubbies",
        "h1" => "Les Teletukillerbeezzzzzz",
        "p" => "C'est flippant.",
        "span-class" => "label-danger",
        "span-text" => "Danger",
        "img-alt" => "Teletubbies",
        "img-src" => "teletubbies.jpg",
    ],
    'kittens' => [
        "title" => "Chat0nxxx!",
        "h1" => "Les Chatons!",
        "p" => "C'est mignon.",
        "span-class" => "label-success",
        "span-text" => "Kawaiiii!",
        "img-alt" => "Teletubbies",
        "img-src" => "three_kittens.jpg",
    ],
    'ironmaiden' => [
        "title" => "Iron Maiden!",
        "h1" => "Iron Maiden!",
        "p" => "C'est vieux.",
        "span-class" => "label-success",
        "span-text" => "SIX SIX SIX!!! the number of the beast!!",
        "img-alt" => "Iron Maiden",
        "img-src" => "ironmaiden.jpg",
    ],
];