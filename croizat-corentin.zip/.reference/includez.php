Incincincincincincinc(david Ghetta)
<?php
if(!function_exists('xon')) {
    function xon()
    {
        echo "OMFG";
    }
}
?>